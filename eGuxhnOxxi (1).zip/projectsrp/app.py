from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = 'my_secret_key'  # Change this to a secure secret key

# Configure the database URI
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///newdb.sqlite3"
db = SQLAlchemy(app)
app.app_context().push()

# Define the User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(80), nullable=False)
    mobile = db.Column(db.String(20), nullable=False)

class Products(db.Model):
  p_id = db.Column(db.Integer, primary_key=True)
  pname=db.Column(db.String, unique=True)
  category=db.Column(db.String)
  unit=db.Column(db.String)
  rate_per_unit=db.Column(db.Integer )
  quantity=db.Column(db.Integer )

class Admin(db.Model):
  a_id = db.Column(db.Integer, primary_key=True)
  name=db.Column(db.String, nullable=False)
  password=db.Column(db.String, unique=False)

class Category(db.Model):
    category_id = db.Column(db.Integer, primary_key=True, unique=True) 
    category_name= db.Column(db.String)

class Cart(db.Model):
    p_id = db.Column(db.Integer, primary_key=True) 
    pname=db.Column(db.String, unique=True)
    quantity=db.Column(db.Integer )
    item_total=db.Column(db.Integer)
    
class UserOrder(db.Model):
    order_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String)
    address = db.Column(db.String)
    contact = db.Column(db.Integer)
    pname = db.Column(db.String)
    quantity = db.Column(db.String)
    total = db.Column(db.Integer)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register')
def register_page():
    return render_template('register.html')

@app.route('/register', methods=['POST'])
def register():
    name = request.form.get('name')
    email = request.form.get('email')
    password = request.form.get('passw')
    mobile = request.form.get('mobile')

    # Check if the email is already registered
    existing_user = User.query.filter_by(email=email).first()
    if existing_user:
        
        return redirect('/')

    # Create a new User object and add it to the database
    new_user = User(name=name, email=email, password=password, mobile=mobile)
    db.session.add(new_user)
    db.session.commit()


    return redirect('/login')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "POST":
        email = request.form.get('email')
        password = request.form.get('passw')
        this_user = User.query.filter_by(email = email).first()
        if this_user:
            if this_user.password == password:  
                # data1=Products.query.all()
                # data2=UserOrder.query.all()
                # cat=db.session.query(Products.category).distinct().all()
                return redirect("/product")
                
            else:
                return "Invalid Password! Please try again"
        else:
            return "User does not exist! Please register yourself!"
    return render_template("login.html")#,data1=data1,cat=cat)


@app.route('/adminlogin', methods=['GET', 'POST'])
def adminlogin():
    if request.method =="POST":
        name = request.form.get('name')
        password = request.form.get('passw')
        new_admin = Admin(name=name, password=password)
        db.session.add(new_admin)
        db.session.commit()
        this_user = Admin.query.filter_by(name = name).first()
        if this_user:
            if this_user.password == password:  
                    # data1=Products.query.all()
                    # data2=UserOrder.query.all()
                    # cat=db.session.query(Products.category).distinct().all()
                return redirect("/adminpanel")#,datna1=data1,cat=cat)
            else:
                return "Invalid Password! Please try again"
        else:
            return "Admin does not exist!"


    return render_template('adminlogin.html')

@app.route('/addcategory', methods = ['GET', 'POST'])
def addcategory():
    name = request.form.get('category_name')
    cat = Category(category_name = name)
    db.session.add(cat)
    db.session.commit()
    return redirect("/adminpanel")

@app.route('/deletecategory', methods = ['GET', 'POST'])
def deletecategory():
    cid = request.form.get('category_id')
    cat_to_delete = Category.query.filter_by(category_id=cid).first()
    if cat_to_delete:
        db.session.delete(cat_to_delete)
        db.session.commit()
            
        return redirect("/adminpanel")
    else:
            # Handle the case where the category doesn't exist
        return "Category not found"
    
@app.route('/deleteproduct', methods = ['GET', 'POST'])
def deleteproduct():
    pid = request.form.get('p_id')
    prod_to_delete = Products.query.filter_by(p_id=pid).first()
    if prod_to_delete:
        db.session.delete(prod_to_delete)
        db.session.commit()
            
        return redirect("/adminpanel")
        
    else:
            # Handle the case where the category doesn't exist
        return "Product not found"

@app.route('/addproduct', methods = ['GET', 'POST'])
def addproduct():
    pname = request.form.get('pname')
    category = request.form.get('category')
    unit = request.form.get('unit')
    rate_per_unit = request.form.get('rate_per_unit')
    quantity = request.form.get('quantity')
    prod = Products(pname=pname,category=category,unit=unit,rate_per_unit=rate_per_unit,quantity=quantity)
    db.session.add(prod)
    db.session.commit()
    return redirect("/adminpanel")
    

@app.route('/adminpanel', methods = ["GET", "POST"])
def adminpanel():
    product = Products.query.all()
    categories = Category.query.all()
    orders = UserOrder.query.all()
    return render_template('adminpanel.html', product = product , categories = categories , orders = orders)
    


@app.route("/updateproduct", methods=['GET', 'POST'])
def updateproduct():
    p_id = request.form.get("p_id")
    pp = Products.query.filter_by(p_id=p_id).first()
    return render_template("updatep.html",p = pp)
    
    #return redirect("updatep.html")

@app.route("/editproduct" , methods=['GET', 'POST'])
def editproduct():
    p_id = request.form.get("p_id")
    npname = request.form.get('pname')
    ncategory = request.form.get('category')
    nunit = request.form.get('unit')
    nrate_per_unit = request.form.get('rate_per_unit')
    nquantity = request.form.get('quantity')
    epd = Products.query.filter_by(p_id = p_id).first()
    epd.pname = npname
    epd.category = ncategory
    epd.unit =nunit
    epd.rate_per_unit = nrate_per_unit
    epd.quantity = nquantity
    db.session.commit()
    return redirect("/adminpanel")

@app.route('/product', methods=['GET','POST'] )
def products():
    pl3=[]
    flag = True
    cart = Cart.query.all()
    for c in cart:
        pl3.append(c.pname)
    if request.method =="POST":
        pl= 0
        sp = request.form.get("sp") 
        prod = Products.query.filter_by(pname = sp)
        for p in prod:
            pl+=1
        if pl == 0:
            pl2 = 0
            prod = Products.query.filter_by(category = sp)
            for j in prod:
                pl2+=1
            if pl2 == 0 :
                return f"no such product or category found please go  and try again"
            else:
                return render_template("product.html" , prod = prod , cart = cart , flag = flag , pl3=pl3)
        
        

        return render_template("product.html" , prod = prod , cart = cart , flag = flag , pl3=pl3)

    else:
        prod = Products.query.all()
        return render_template('product.html', prod=prod , cart = cart , flag = flag ,  pl3=pl3)

@app.route("/cart/<int:p_id>")
def add_to_cart(p_id):
    c1=Cart.query.all() 
    flag = True
    for c in c1:
        if p_id == c.p_id:
            flag = False
    if flag == True:
        tp = Products.query.filter_by(p_id = p_id).first()
        tpn = tp.pname
        tqt = 1
        tit = tp.rate_per_unit*tqt
        crt = Cart(p_id = p_id, pname = tpn, quantity=tqt, item_total= tit)
        db.session.add(crt)
        db.session.commit()
    else:
        crt = Cart.query.filter_by(p_id = p_id).first()
        crtq = crt.quantity+1
        crt2 = Cart(p_id = p_id, pname = crt.pname, quantity=crtq, item_total= crt.item_total)
        db.session.delete(crt)
        db.session.add(crt2)
        db.session.commit()   
    return redirect('/product')

@app.route("/viewcart", methods=["GET", "POST"])
def viewcart():
    if request.method == "POST":
        name = request.form.get('Name')
        address = request.form.get('Address')
        contact =  request.form.get('Contact')
        items = Cart.query.all()
        qnty = 0
        Item_name = ""
        temp_total = 0
        for i in items:
            temp_p = Products.query.filter_by(p_id = i.p_id).first()
            temp_p.quantity = temp_p.quantity - i.quantity
            qnty += i.quantity 
            Item_name += i.pname
            temp_total += i.item_total
            db.session.commit()
        temp_order = UserOrder(name=name, address=address, contact=contact, pname=Item_name, quantity = qnty, total = temp_total)
        db.session.add(temp_order)
        db.session.commit()
        for j in items:
            db.session.delete(j)  
            db.session.commit()

        return f"Thanks for shopping with us"
        
    else:
        temp_cart = Cart.query.all()
        total = 0
        for item in temp_cart:
            total += item.item_total
        return render_template('viewcart.html', temp_cart = temp_cart, total = total)

@app.route("/remove/<int:p_id>")
def remove(p_id):
    rem = Cart.query.filter_by(p_id=p_id).first()
    db.session.delete(rem)
    db.session.commit()
    return redirect("/viewcart")

if __name__ == '__main__':
    # Create the database tables
    with app.app_context():
        db.create_all()
    app.run(debug=True)