Sample User Login:
    email: abc@gmail.com
    password: abc
Admin Login:
    name: admin
    password: admin 
       
